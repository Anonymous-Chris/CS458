import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NepalPage } from './nepal';

@NgModule({
  declarations: [
    NepalPage,
  ],
  imports: [
    IonicPageModule.forChild(NepalPage),
  ],
})
export class NepalPageModule {}
